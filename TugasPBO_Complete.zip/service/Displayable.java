package service;

public interface Displayable {
    String getDisplayText();
}